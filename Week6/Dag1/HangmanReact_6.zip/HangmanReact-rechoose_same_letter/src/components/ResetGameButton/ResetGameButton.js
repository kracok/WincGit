import React from "react";

const ResetGameButton = props => (
  <input type="button" value="reset" onClick={props.click} />
);

export default ResetGameButton;
